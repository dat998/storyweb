<?php
   
    include_once("./connect.php");
    $id = $_GET['idChap'];

    $sql = "UPDATE comment set status = 1 where id_comment='$id'";
    $conn->query($sql);
    header("Location: ./../html/user/user-edit.php?value=5");

?>