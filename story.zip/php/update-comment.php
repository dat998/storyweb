<?php
    session_start();
    include_once("./connect.php");
    $value = $_POST['value'];
    $id = $_POST['update-value'];

    echo $value;
    echo $id;
    if($_SESSION['role']=='admin'){
        $sql = "UPDATE comment set value='$value', status=1 where id_comment='$id'";
        $conn->query($sql);
    }
    elseif($_SESSION['role']=='user'){
        $sql = "UPDATE comment set value='$value', status=0 where id_comment='$id'";
        $conn->query($sql);
    }
    

    header("Location:./../html/readStory.php?story-name=".$_SESSION['story_name']."&&chap-number=1");
?>