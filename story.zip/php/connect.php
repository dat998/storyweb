<?php
    $username = "root"; // Khai báo username
    $password = "";      // Khai báo password
    $server   = "localhost";   // Khai báo server
    $dbname   = "story";      // Khai báo database
    $conn=new mysqli($server,$username,$password,$dbname);
?>