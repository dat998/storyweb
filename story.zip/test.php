<?php
    include("./php/connect.php");

    // $sql="SELECT * from views";
    // $result = $conn->query($sql);

    $sql1 = "SELECT point_story,views,id,point_rate from stories";
    $result1 = $conn->query($sql1);
    $count=0;
    while($row1  = $result1->fetch_assoc()){
        $point = $row1['point_story'];
        $view = $row1['views'];
        $id = $row1['id'];
        $rate = $row1['point_rate'];

        $sql = "INSERT into views(id_story,views,point_story,point_rate) values('$id','$view','$point','$rate')";
        $conn->query($sql);
        echo '<p>'.$point.'|'.$view.'|'.$id.'|'.$rate.'</p>';
        $count++;
    }
    echo $count;

?>


